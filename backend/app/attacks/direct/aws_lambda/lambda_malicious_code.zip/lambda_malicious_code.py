def lambda_handler(event, context):
    print("Injecting malicious code into a Lambda function")
    print("Injecting malicious code into a Lambda function")
    print("Injecting malicious code into a Lambda function")
    print("Injecting malicious code into a Lambda function")
    print("Injecting malicious code into a Lambda function")
